import React from 'react';
import { Draggable } from 'react-beautiful-dnd';

function getBorderColor(situation) {
  switch (situation) {
    case 'Futuro': return 'border-gray-500';
    case 'Em andamento': return 'border-green-500';
    case 'Finalizado': return 'border-blue-700';
    case 'Paralisado': return 'border-yellow-500';
    case 'Cancelado': return 'border-red-500';
    case 'Excluído': return 'border-gray-300 text-gray-400';
    default: return 'border-blue-400';
  }
}

export default function CardItem({ task, index, situation, onClick, toggleDestacado }) {
  const borderColor = getBorderColor(situation);

  return (
    <Draggable draggableId={task.id} index={index}>
      {(provided, snapshot) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
          onClick={onClick}
          className={`relative bg-white rounded shadow p-3 mb-2 cursor-pointer transition-colors border-l-4 ${borderColor} ${
            snapshot.isDragging ? 'bg-blue-50' : ''
          }`}
        >
          {/* Botão de destaque */}
          <button
            onClick={(e) => {
              e.stopPropagation(); // Evita abrir o modal de detalhes
              toggleDestacado(task.id);
            }}
            className="absolute top-1 right-1 focus:outline-none"
          >
            {task.destacado ? (
              <svg
                className="w-5 h-5 text-yellow-500"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.95a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.37 2.447a1 1 0 00-.364 1.118l1.287 3.95c.3.92-.755 1.688-1.54 1.118L10 13.347l-3.367 2.447c-.785.57-1.84-.197-1.54-1.118l1.286-3.95a1 1 0 00-.364-1.118L2.671 9.377c-.783-.57-.38-1.81.588-1.81h4.162a1 1 0 00.95-.69l1.286-3.95z" />
              </svg>
            ) : (
              <svg
                className="w-5 h-5 text-gray-300"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.95a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.37 2.447a1 1 0 00-.364 1.118l1.287 3.95c.3.92-.755 1.688-1.54 1.118L10 13.347l-3.367 2.447c-.785.57-1.84-.197-1.54-1.118l1.286-3.95"
                />
              </svg>
            )}
          </button>

          <p className="text-xs">
            <strong>{task.empresa}</strong> | {task.conta}
          </p>
          <h3 className="text-sm font-bold mt-1">{task.assunto}</h3>
          <p className="text-xs mt-1">
            Abertura: {task.abertura} | Entrega: {task.entrega}
          </p>
          <p className="text-xs mt-1 line-clamp-2">
            {task.resumo}
          </p>
        </div>
      )}
    </Draggable>
  );
}