import React, { useState } from 'react';

export default function FilterModal({ onClose, onFilter }) {
  const [empresa, setEmpresa] = useState('');
  const [conta, setConta] = useState('');
  const [situacao, setSituacao] = useState('');
  const [dataDe, setDataDe] = useState('');
  const [dataAte, setDataAte] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onFilter({ empresa, conta, situacao, dataDe, dataAte });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-30 flex justify-center items-center">
      <div className="bg-white p-4 rounded w-[300px] shadow-md">
        <h2 className="text-lg font-bold mb-2">Filtrar Tráfegos</h2>
        <form onSubmit={handleSubmit}>
        <div className="flex items-center mb-2">
          <input
            type="checkbox"
            id="destacados"
            checked={destacados}
            onChange={(e) => setDestacados(e.target.checked)}
            className="mr-2"
          />
          <label htmlFor="destacados" className="text-sm">
            Somente destacados
          </label>
        </div>

        <label className="block mb-1 text-sm">Empresa</label>
          <input
            className="border w-full mb-2 p-1"
            value={empresa}
            onChange={(e) => setEmpresa(e.target.value)}
          />

          <label className="block mb-1 text-sm">Conta</label>
          <input
            className="border w-full mb-2 p-1"
            value={conta}
            onChange={(e) => setConta(e.target.value)}
          />

          <label className="block mb-1 text-sm">Situação</label>
          <select
            className="border w-full mb-2 p-1"
            value={situacao}
            onChange={(e) => setSituacao(e.target.value)}
          >
            <option value="">(Todas)</option>
            <option value="column-futuro">Futuro</option>
            <option value="column-em-andamento">Em andamento</option>
            <option value="column-finalizado">Finalizado</option>
            <option value="column-paralisado">Paralisado</option>
            <option value="column-cancelado">Cancelado</option>
            <option value="column-excluido">Excluído</option>
          </select>

          <label className="block mb-1 text-sm">Data De</label>
          <input
            type="date"
            className="border w-full mb-2 p-1"
            value={dataDe}
            onChange={(e) => setDataDe(e.target.value)}
          />

          <label className="block mb-1 text-sm">Data Até</label>
          <input
            type="date"
            className="border w-full mb-2 p-1"
            value={dataAte}
            onChange={(e) => setDataAte(e.target.value)}
          />

          <div className="flex justify-end gap-2 mt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1 bg-gray-300 rounded"
            >
              Fechar
            </button>
            <button
              type="submit"
              className="px-3 py-1 bg-blue-500 text-white rounded"
            >
              Filtrar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}