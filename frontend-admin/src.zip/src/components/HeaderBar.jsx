import React from 'react';

export default function HeaderBar({ onFilterClick, onNewClick }) {
  return (
    <div className="flex items-center bg-blue-700 px-4 py-2 text-white">
      {/* Nome do Board */}
      <h1 className="text-xl font-bold mr-4">Quadro de Tráfegos</h1>

      {/* Exemplo de “estrela” / Workspace, se quiser */}
      <button className="px-2 py-1 hover:bg-blue-600 rounded text-sm mr-4">
        <svg
          className="w-4 h-4 inline-block"
          fill="currentColor"
          viewBox="0 0 20 20"
        >
          <path d="M10 15l-5.878 3.09 1.122-6.54L.488 6.91l6.557-.95L10 0l2.955 5.96 6.557.95-4.756 4.64 1.122 6.54L10 15z" />
        </svg>
      </button>

      {/* Barra de Busca */}
      <div className="flex items-center bg-blue-600 px-2 py-1 rounded mr-4 w-64">
        <svg
          className="w-4 h-4 text-white mr-2"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round"
            d="M21 21l-4.867-4.867m0 0A7.5 7.5 0 1110.5 3a7.5 7.5 0 015.633 12.133z"
          />
        </svg>
        <input
          type="text"
          placeholder="Buscar..."
          className="bg-transparent focus:outline-none text-sm w-full"
        />
      </div>

      {/* Botões à direita */}
      <div className="ml-auto flex items-center gap-2">
        <button
          onClick={onFilterClick}
          className="bg-blue-600 hover:bg-blue-500 px-3 py-1 rounded text-sm"
        >
          Filtrar
        </button>
        <button
          onClick={onNewClick}
          className="bg-green-500 hover:bg-green-400 px-3 py-1 rounded text-sm"
        >
          Novo
        </button>

        {/* Avatar do usuário (opcional) */}
        <img
          src="https://via.placeholder.com/32"
          alt="User Avatar"
          className="w-8 h-8 rounded-full ml-3"
        />
      </div>
    </div>
  );
}